from brain_games.games.progression_game import game_generator


# The script that starts the game
def main():
    game_generator()
