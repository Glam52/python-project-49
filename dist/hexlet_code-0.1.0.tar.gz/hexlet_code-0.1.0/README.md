### Hexlet tests and linter status:
[![Actions Status](https://github.com/Glam52/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Glam52/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/d60bce503c87d30cc9b5/maintainability)](https://codeclimate.com/github/Glam52/python-project-49/maintainability)