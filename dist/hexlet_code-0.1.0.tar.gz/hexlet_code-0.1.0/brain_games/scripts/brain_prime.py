from brain_games.games.prime_game import game_generator


# The script that starts the game
def main():
    game_generator()
